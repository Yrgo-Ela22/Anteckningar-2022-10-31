/********************************************************************************
* main.c: Demonstration av strukt f�r lagring, ber�kning samt utskrift av
*         parametrar f�r tv� rum.
********************************************************************************/
#include "room.h"

/********************************************************************************
* main: Lagrar l�ngd, bredd samt h�jd f�r tv� rum. Rummens parametrar skrivs
*       ut i terminalen samt till en fil d�pt room.txt.
********************************************************************************/
int main(void)
{
   struct room r1, r2;
   FILE* ostream = fopen("room.txt", "w"); 

   room_init(&r1, 10, 5, 2.5); 
   room_init(&r2, 5, 2.5, 10);

   room_print(&r1, 0); 
   room_print(&r2, 0);

   room_print(&r1, ostream);
   room_print(&r2, ostream);
   
   return 0;
}

