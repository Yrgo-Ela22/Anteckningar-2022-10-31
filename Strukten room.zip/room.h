/********************************************************************************
* room.h: Inneh�ller funktionalitet f�r lagring, ber�kning samt utskrift av
*         parametrar f�r rum via strukten room samt associerade funktioner.
********************************************************************************/
#ifndef ROOM_H_
#define ROOM_H_

/* Inkluderingsdirektiv: */
#include <stdio.h>

/********************************************************************************
* room: Strukt f�r lagring, ber�kning samt utskrift av parametrar f�r rum.
********************************************************************************/
struct room
{
   double length; /* Rummets l�ngd i meter. */
   double width;  /* Rummets bredd i meter. */
   double height; /* Rummets h�jd i meter. */
};

/********************************************************************************
* room_init: Initierar nytt room-objekt med angivna parametrar.
*
*            - self: Pekare till room-objektet som ska initieras.
*            - length: Rummets l�ngd i meter.
*            - width : Rummets bredd i meter.
*            - height: Rummets h�jd i meter.
********************************************************************************/
void room_init(struct room* self, 
               const double length,
               const double width,
               const double height);

/********************************************************************************
* room_clear: Nollst�ller parametrar f�r angivet rum.
* 
*             - self: Pekare till rummet vars parametrar ska nollst�llas.
********************************************************************************/
void room_clear(struct room* self);

/********************************************************************************
* room_get_area: Returnerar arean f�r angivet rum i kvadratmeter.
* 
*                - self: Pekare till rummet vars area ska ber�knas.
********************************************************************************/
double room_get_area(const struct room* self);

/********************************************************************************
* room_get_volume: Returnerar volymen f�r angivet rum i kubikmeter.
*
*                  - self: Pekare till rummet vars volym ska ber�knas.
********************************************************************************/
double room_get_volume(const struct room* self);

/********************************************************************************
* room_print: Skriver ut l�ngd, bredd, h�jd, area samt volym f�r angivet rum via
*             angiven utstr�m, d�r standardutenhet stdout anv�nds som default
*             f�r utskrift i terminalen.
*
*        - self   : Pekare till rummet vars parametrar ska skrivas ut.
*        - ostream: Referens till angiven utstr�m (default = std::cout).
********************************************************************************/
void room_print(const struct room* self,
                FILE* ostream);

#endif /* ROOM_H_ */